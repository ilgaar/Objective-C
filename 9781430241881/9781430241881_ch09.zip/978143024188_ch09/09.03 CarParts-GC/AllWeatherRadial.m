#import "AllWeatherRadial.h"

@implementation AllWeatherRadial

- (NSString *) description
{
    return (@"I am a tire for rain or shine.");
} // description

@end // AllWeatherRadial

