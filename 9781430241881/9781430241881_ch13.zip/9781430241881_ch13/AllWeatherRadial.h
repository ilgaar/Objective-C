#import <Foundation/Foundation.h>
#import "Tire.h"

@interface AllWeatherRadial : Tire

@property float rainHandling;
@property float snowHandling;

@end // AllWeatherRadial
